Eu entendi que a Engenharia de Software está relacionada com construir algo que acompanhe as constantes mudanças externas do que se é exigido, tendo em vista que acompanhar essas mudanças é arriscado, tanto para a eficiência quanto para o tempo. Ou seja, tempo, escala e trade-offs - estando sempre sujeita a mudanças.
A relação com programação: A relação com a programação envolve a manutenção e o tempo, como o desenvolvimento desse software compromete estes dois fatores.
O que são requisitos:
2.1 Funcionais? Requisitos funcionais no contexto de um software quer dizer o que o mesmo irá fazer e como irá se comportar, bem como as funcionalidades que ele não terá.
2.2 Não funcionais? Os requisitos não funcionais tem a ver com a segurança, confiabilidade e disponibilidade do software, isto é, atributos que fazem parte do desenvolvimento desse software.
2.3 Exemplos:
Dispor de operações HTTP na camada de controllers do backend ou dispor juntamente com outras operações, misturando regras de negócio
Tratar formatações de data no banco de dados ou no frontend